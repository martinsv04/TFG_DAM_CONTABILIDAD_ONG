package com.tfg.ong.model;

public enum TipoReporte {
    BALANCE_GENERAL,
    ESTADO_RESULTADOS,
    FLUJO_EFECTIVO ;
}
