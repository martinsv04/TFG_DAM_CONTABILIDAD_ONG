package com.tfg.ong.model;

public enum Categoria {
    PERSONAL,
    SUMINISTROS,
    ALQUILER,
    TRANSPORTE,
    FORMACIÓN,
    COMUNICACIÓN,
    OTROS ;
}
