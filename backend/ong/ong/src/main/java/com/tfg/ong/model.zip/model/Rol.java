package com.tfg.ong.model;

public enum Rol {
    ADMIN,
    CONTABLE,
    VOLUNTARIO,
    DONANTE ;
}

