package com.tfg.ong.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tfg.ong.model.Reporte;

public interface ReporteRepository extends JpaRepository<Reporte, Long>{

}
