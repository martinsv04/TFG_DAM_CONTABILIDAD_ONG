package com.tfg.ong;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OngApplicationTests {

	@Test
	void contextLoads() {
	}

}
