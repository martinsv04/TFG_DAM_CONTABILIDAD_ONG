package com.tfg.ong.repository;

import com.tfg.ong.model.DetalleFactura;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DetalleFacturaRepository extends JpaRepository<DetalleFactura, Long>{
    
}
